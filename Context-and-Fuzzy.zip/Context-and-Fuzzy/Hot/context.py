import cv2 as cv
import numpy as np


#欧式比较

def contrast(gm,area,aaa,bbb):
    k=0
    d=100
    pdist1=((gm-aaa)**2)**0.5 
    pdist2=((area-bbb)**2)**0.5 
    d=(pdist1+pdist2)/2
    #距离标准化
    d=int(d)
    d=((d-10)/250)*100
    if d<=25:
        k=1
    return k




def contex1(dir,j):
    #当前图像
    image=cv.imread(dir[j])
    grayimage = cv.cvtColor(image, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv.threshold(grayimage, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)

    #当前图像特征提取
    gm=cv.mean(grayimage)[0]
    area=len(binaryimage[binaryimage==255])


    #一张上下文图像
    image1=cv.imread(dir[j-1])
    grayimage1 = cv.cvtColor(image1, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage1 = cv.threshold(grayimage1, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
  
  


    #所有上下文特征
    gm1=cv.mean(grayimage1)[0]
    area1=len(binaryimage1[binaryimage1==255])

    #上下文对比算法
    aa=gm1
    bb=area1
    k=contrast(gm,area,aa,bb)

    return k


def contex2(dir,j):
    #当前图像
    image=cv.imread(dir[j])
    grayimage = cv.cvtColor(image, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv.threshold(grayimage, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)

    #当前图像特征提取
    gm=cv.mean(grayimage)[0]
    area=len(binaryimage[binaryimage==255])


    #两张上下文图像
    image1=cv.imread(dir[j-1])
    image2=cv.imread(dir[j-2])
    grayimage1 = cv.cvtColor(image1, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage1 = cv.threshold(grayimage1, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
    grayimage2 = cv.cvtColor(image2, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage2 = cv.threshold(grayimage2, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
  


    #所有上下文特征
    gm1=cv.mean(grayimage1)[0]
    gm2=cv.mean(grayimage2)[0]

    area1=len(binaryimage1[binaryimage1==255])
    area2=len(binaryimage2[binaryimage2==255])






    #上下文对比算法

    A=[gm1,gm2]#灰度越小越真
    A1=sorted(A)
    A2=[A.index(A1[0]),A.index(A1[1])]#升序排列的A的下标
    B=[area1,area2]#面积越大越真。做一个copy数组A1,用来降序并在原数组中找到对应的index,A2保存index
    B1=sorted(B,reverse = True)
    B2=[B.index(B1[0]),B.index(B1[1])]#降序排列的B的下标
    
    aa=A[A2[0]]
    bb=B[B2[0]]
    k=contrast(gm,area,aa,bb)
    
    return k



#上下文比较
def contex3(dir,j):
    #当前图像
    image=cv.imread(dir[j])
    grayimage = cv.cvtColor(image, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv.threshold(grayimage, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)

    #当前图像特征提取
    gm=cv.mean(grayimage)[0]
    area=len(binaryimage[binaryimage==255])


    #三张上下文图像
    image1=cv.imread(dir[j-1])
    image2=cv.imread(dir[j-2])
    image3=cv.imread(dir[j-3])
    grayimage1 = cv.cvtColor(image1, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage1 = cv.threshold(grayimage1, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
    grayimage2 = cv.cvtColor(image2, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage2 = cv.threshold(grayimage2, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
    grayimage3 = cv.cvtColor(image3, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage3 = cv.threshold(grayimage3, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)


    #所有上下文特征
    gm1=cv.mean(grayimage1)[0]
    gm2=cv.mean(grayimage2)[0]
    gm3=cv.mean(grayimage3)[0]

    area1=len(binaryimage1[binaryimage1==255])
    area2=len(binaryimage2[binaryimage2==255])
    area3=len(binaryimage3[binaryimage3==255])





    #上下文对比算法

    A=[gm1,gm2,gm3]#灰度越小越真
    A1=sorted(A)
    A2=[A.index(A1[0]),A.index(A1[1]),A.index(A1[2])]#升序排列的A的下标
    B=[area1,area2,area3]#面积越大越真。做一个copy数组A1,用来降序并在原数组中找到对应的index,A2保存index
    B1=sorted(B,reverse = True)
    B2=[B.index(B1[0]),B.index(B1[1]),B.index(B1[2])]#降序排列的B的下标
    #print(gm,area,A,A2,B,B2)
    aa=A[A2[0]]
    bb=B[B2[0]]
    k=contrast(gm,area,aa,bb)
    
    return k


def contex4(dir,j):
    #当前图像
    image=cv.imread(dir[j])
    grayimage = cv.cvtColor(image, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv.threshold(grayimage, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)

    #当前图像特征提取
    gm=cv.mean(grayimage)[0]
    area=len(binaryimage[binaryimage==255])


    #四张上下文图像
    image1=cv.imread(dir[j-1])
    image2=cv.imread(dir[j-2])
    image3=cv.imread(dir[j-3])
    image4=cv.imread(dir[j-4])
    grayimage1 = cv.cvtColor(image1, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage1 = cv.threshold(grayimage1, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
    grayimage2 = cv.cvtColor(image2, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage2 = cv.threshold(grayimage2, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
    grayimage3 = cv.cvtColor(image3, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage3 = cv.threshold(grayimage3, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)
    grayimage4 = cv.cvtColor(image4, cv.COLOR_BGR2GRAY)#灰度
    _O, binaryimage4 = cv.threshold(grayimage4, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)


    #所有上下文特征
    gm1=cv.mean(grayimage1)[0]
    gm2=cv.mean(grayimage2)[0]
    gm3=cv.mean(grayimage3)[0]
    gm4=cv.mean(grayimage4)[0]

    area1=len(binaryimage1[binaryimage1==255])
    area2=len(binaryimage2[binaryimage2==255])
    area3=len(binaryimage3[binaryimage3==255])
    area4=len(binaryimage3[binaryimage4==255])





    #上下文对比算法

    A=[gm1,gm2,gm3,gm4]#灰度越小越真
    A1=sorted(A)
    A2=[A.index(A1[0]),A.index(A1[1]),A.index(A1[2]),A.index(A1[3])]#升序排列的A的下标
    B=[area1,area2,area3,area4]#面积越大越真。做一个copy数组A1,用来降序并在原数组中找到对应的index,A2保存index
    B1=sorted(B,reverse = True)
    B2=[B.index(B1[0]),B.index(B1[1]),B.index(B1[2]),B.index(B1[3])]#降序排列的B的下标
    #print(gm,area,A,A2,B,B2)
    aa=A[A2[0]]
    bb=B[B2[0]]
    k=contrast(gm,area,aa,bb)
    
    return k















