# -*- coding: UTF-8 -*-
import os
from re import T
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import torch
from torch.autograd import Variable
import numpy as np
import cv2
import sys
import io
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf8')
from context import contex1 as contx

#插值型隶属函数
#A1=[1417,3054,3474,3803,4058]
def A1 (x):
    f=0
    if x>=1417 and x<=3474:
        f1=(1/2057)*x+(-1417/2057)
        f=f1
    if x>3474 and x<=4058:
        f2=(-1/584)*x+(2029/292)
        f=f2
    return(f)
#A0=[720,1570,1776,1990,2780]
def A0 (x):
    f=0
    if x>=720 and x<=1776:
        f1=(1/1056)*x+(-15/22)
        f=f1
    if x>1776 and x<=2780:
        f2=(-1/1004)*x+(695/251)
        f=f2
    return(f)

#G1=[53,109,128,144,188]
def G1 (x):
    f=0
    if x>=53 and x<=128:
        f1=(1/75)*x+(-53/75)
        f=f1
    if x>128 and x<=188:
        f2=(-1/60)*x+(47/15)
        f=f2
    return(f)

#G0=[71,98,113,133,151]
def G0 (x):
    f=0
    if x>=71 and x<=113:
        f1=(1/42)*x+(-71/42)
        f=f1
    if x>113 and x<=151:
        f2=(-1/38)*x+(151/38)
        f=f2
    return(f)



#加载训练好的网络
net = torch.load('network\\net10.pth')










#数据化函数
def point(img):
    image=img
    grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv2.threshold(grayimage, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)

    gm=cv2.mean(grayimage)[0]
    area=len(binaryimage[binaryimage==255])
    #算出四个隶属值
    #A1
    a1=A1(area)
    #A0
    a0=A0(area)
    #G1
    g1=G1(gm)
    #G0
    g0=G0(gm)

    #隶属乘法器
    pai1=a1*g1
    pai2=a0*g0

    d=[]
    d.extend([pai1,pai2])
    return d



#网络输出
def OutPut(data):
    target = np.array(data)
    target = torch.from_numpy(target).float()

    target=(net(target))[0][0]
    return('%.20f' % target)


def Judge(img,dir,j):
    #不确定区间范围
    U=68
    H=78
    #填涂选项数据化
        #读入图像
    image1=img

        #四个填涂选项隶属数据化
    A=point(image1)
   

        #保存隶属数据
    dataA=[]
    dataA.append(A)


    #预测结果
    a=float(OutPut(dataA))
    #结果标准化
    a=((a-0.009407073)/abs(0.009407073-1.033232093))*100
    results=[]
    if a>=H:
        results.append("有瑕疵")
    elif a>U and a<H:
        k=contx(dir,j)
        if k==1:
            results.append("有瑕疵")
        else:
            results.append("无瑕疵")
    else:
        results.append("无瑕疵")
  
    print(results)
    return(results)




##批量读入图像路径
Dir=[]
length=len(os.listdir("Test set"))

#读入图片地址
for i in range(length):
    Dir.append("Test set\\{}.jpg".format(str(i+1))) 

#输出结果
lll=[]
for j in range(length):
    #print("No.",j+1)
    image=cv2.imread(Dir[j])
    Judge(image,Dir,j)




