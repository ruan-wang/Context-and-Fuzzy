import cv2
import imutils
import numpy as np
import pandas as pd
import os



A0=[]
A1=[]


#批量读取
list0=[]
length0=len(os.listdir("image\\2F"))
list1=[]
length1=len(os.listdir("image\\2T"))
print(length1,length0)
#读入图片地址
for i in range(length0):
    list0.append("image\\2F\\{}.jpg".format(str(i+1))) 
for m in range(length1):
    list1.append("image\\2T\\{}.jpg".format(str(m+1))) 
#对读入的图片批量操作
for j in range(length0):
    image=cv2.imread(list0[j])
    grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv2.threshold(grayimage, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    area=len(binaryimage[binaryimage==255])
    A0.append(area)

for k in range(length1):
    image=cv2.imread(list1[k])
    grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv2.threshold(grayimage, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    area=len(binaryimage[binaryimage==255])
    A1.append(area)



print(A0)
print(A1)



#数值写入CSV文件
A0 = np.array(A0)
A1 = np.array(A1)
# 先转为DataFrame格式
name=["A0"]
df1 = pd.DataFrame(columns=name, data=A0)
df1.to_csv("statistics results\\A0.csv")
name=["A1"]
df2 = pd.DataFrame(columns=name, data=A1)
df2.to_csv("statistics results\\A1.csv")