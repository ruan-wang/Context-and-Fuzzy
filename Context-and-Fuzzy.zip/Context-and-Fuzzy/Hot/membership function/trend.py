import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math
from scipy import stats
import sys
import io
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf8')



corpus = pd.read_csv('statistics results\\G1.csv',header=0, names=["G1"]) # 得到 DataFrame
corpus = np.array(corpus)  # 转换为 ndarray [[1], [2], [3]]
corpus = corpus.reshape(1, len(corpus)).tolist()  # 转换成 List [[1, 2, 3]]
corpus = corpus[0]  # 取第一个元素得到最终结果 [1, 2, 3]
X = np.array(corpus)
X=sorted(X)
X1=stats.mode(X)[0][0]

print("中位数是",X[148])
print("众数是",X1)
print("最小值是",min(X))
print("最大值是",max(X))
print(X)