import numpy as np
from numpy.linalg import solve
import matplotlib.pyplot as plt
from sympy import symbols, solve, linsolve
np.set_printoptions(precision=4)



#算正态分布模糊集
def Gdt(x,xm,s2):
    if abs(x-xm)>(2*s2):
        return 0
    else:
        return (1-((x-xm)**2/(4*s2)))


def A1 (x):
    f=Gdt(x,691.8513514,91809)
    return(f)


#画出函数
    #定义x、y散点坐标
x=[]
y=[]
y1=[]
for i in range (1417,4058):
    x.append(i)
for j in range (len(x)):
    a1=A1(x[j])
    y.append(a1)

x=np.array(x)
y=np.array(y)

plt.xlabel('x')
plt.ylabel('y')
plt.plot(x,y,'black',label='fx')
plt.title('exp')
plt.legend(loc=4) #指定legend的位置右下角
plt.show()

'''    if compare(Ai(Gdt(gm,127.8321104,84.31149125),Gdt(area,691.8513514,91809)),Ai(Gdt(gm,201.265412,78.53247543),Gdt(area,11.1565254,249032.0686)))==1 :
            x.append("有瑕疵")'''