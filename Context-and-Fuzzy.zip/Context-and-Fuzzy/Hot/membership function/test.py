import numpy as np
import matplotlib.pyplot as plt
import math
 
#定义x、y散点坐标
x=[]
y=[]
y1=[]
for i in range (50):
    x.append(i)
for j in range (50):
    y.append((-2*j+1)**3)
for j in range (50):
    y1.append(2*j+1)
'''y3=1.90094999*math.pow(10,-10)*x3**3-2.33433765*math.pow(10,-6)*x3**2+9.01913197*math.pow(10,-3)*x3-1.04800377*math.pow(10,1)'''



x=np.array(x)
y=np.array(y)
y1=np.array(y1)

plt.xlabel('x')
plt.ylabel('y')
plt.plot(x,y,'black',label='fx')
plt.plot(x,y1,'r',label='LR')
plt.title('exp')
plt.legend(loc=4) #指定legend的位置右下角
plt.show()

