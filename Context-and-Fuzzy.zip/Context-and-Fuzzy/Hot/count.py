# -*- coding: UTF-8 -*-
import os

from matplotlib import image
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import torch
from torch.autograd import Variable
import numpy as np
import cv2 as cv
import sys
import io
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf8')
from context import contex1


'''L=[]
for i in range(10):
    x=input("请输入：")
    x=float(x)
    acc=float((1000-x)/1000)
    acc=acc*100
    acc="%.2f"%acc
    L.append(acc)
print(L)'''


#答题卡
'''x=input("请输入：")
x=float(x)
acc=float((1000-x)/1000)
acc=acc*100
acc="%.2f"%acc
print(acc)'''

#热轧带

L=[]
for i in range (7):
    x=input("请输入：")
    x=float(x)
    acc=float((592-x)/592)
    acc=acc*100
    acc="%.2f"%acc
    L.append(acc)
print(L)