from multiprocessing import context
import os
from tkinter import image_names
from unicodedata import category
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import torch
from torch.autograd import Variable
import numpy as np
import cv2
from Context2 import contextcmp
import random
from random import sample
from M_function import A1,A0,M_degree
from preprocessing import imgpre

#加载训练好的网络
#net = torch.load('network2\\net2.pth')
net = torch.load('network\\network H10\\net1.pth')

#网络输出
def OutPut(data):
    target = np.array(data)
    target = torch.from_numpy(target).float()

    target=(net(target))[0][0]
    return('%.20f' % target)


def Judge(img,imghis,J,dir):
    
    #读入图像和图像编号
    image=img
    his=imghis
    index=J

    #四个填涂选项隶属数据化
    A=M_degree(imgpre(image)[0])
    B=M_degree(imgpre(image)[1])
    C=M_degree(imgpre(image)[2])
    D=M_degree(imgpre(image)[3])
    #保存四个选项的隶属数据
    degreeA=[]
    degreeA.append(A)
    degreeB=[]
    degreeB.append(B)
    degreeC=[]
    degreeC.append(C)
    degreeD=[]
    degreeD.append(D)




    #预测结果(0~1之间)
    a=float(OutPut(degreeA))
    b=float(OutPut(degreeB))
    c=float(OutPut(degreeC))
    d=float(OutPut(degreeD))
    #结果标准化
    a=((a-0.030774057)/abs(0.030774057-0.662137806))*100
    b=((b-0.030774057)/abs(0.030774057-0.662137806))*100
    c=((c-0.030774057)/abs(0.030774057-0.662137806))*100
    d=((d-0.030774057)/abs(0.030774057-0.662137806))*100
    results=[]



#对每一个选项进行预测（不确定区间&上下文）

    #context为上下文算法，image为当前选项所在图片，imagehis为上一张图片，1、2、3、4为选项编号
    #不确定区间范围
    U=40
    H=60
    
    if a>=H:
        results.append('A')
    if a>=U and a<H:
        k=contextcmp(image,his,1)[0]
        category=contextcmp(image,his,1)[1]
        if k==1:
            results.append(category)


    if b>=H:
        results.append('B')
    if b>=U and b<H:
        k=contextcmp(image,his,2)[0]
        category=contextcmp(image,his,2)[1]
        if k==1:
            results.append(category)


    if c>=H:
        results.append('C')
    if c>=U and c<H:
        k=contextcmp(image,his,3)[0]
        category=contextcmp(image,his,3)[1]
        if k==1:
            results.append(category)


    if d>=H:
        results.append('D')
    if d>=U and d<H:
        k=contextcmp(image,his,4)[0]
        category=contextcmp(image,his,4)[1]
        if k==1:
            results.append(category)

    #缺陷补全
    if index==0 and len(results)==0:
        results.append('Q')
     

    if index!=0 and len(results)==0:
        results.append('Q')
       

  
    return(results)

    
    #active learning!
    #如果是第一张图片没有给出结果，抛给人
'''
    if index==0 and len(results)==0:
        image111=cv2.imread(dir[index])
        cv2.imshow("image",image111)
        cv2.waitKey(2000)
        List=input()
        results=List.split(",")

     
    #如果上下文还是没有给出结果，抛给人

    if index!=0 and len(results)==0:
        image111=cv2.imread(dir[index])
        cv2.imshow("image",image111)
        cv2.waitKey(2000)
        List=input()
        results=List.split(",")

  
    return(results)

'''    













