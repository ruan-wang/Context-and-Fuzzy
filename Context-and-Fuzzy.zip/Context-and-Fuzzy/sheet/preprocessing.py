import numpy as np
import cv2

def imgpre(image):
    a=image[37:70,18:95]
    b=image[37:70,119:192]
    c=image[37:70,218:289]
    d=image[37:70,315:387]

    grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
    _O, binaryimage = cv2.threshold(grayimage, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    #选项特征提取
    gm=cv2.mean(grayimage)[0]
    binaryimage111=binaryimage
    area=len(binaryimage111[binaryimage111==255])

    gm1=cv2.mean(a)[0]
    gm2=cv2.mean(b)[0]
    gm3=cv2.mean(c)[0]
    gm4=cv2.mean(d)[0]

    binaryimage1=binaryimage[37:70,18:95]
    binaryimage2=binaryimage[37:70,119:192]
    binaryimage3=binaryimage[37:70,218:289]
    binaryimage4=binaryimage[37:70,315:387]
    area1=len(binaryimage1[binaryimage1==255])
    area2=len(binaryimage2[binaryimage2==255])
    area3=len(binaryimage3[binaryimage3==255])
    area4=len(binaryimage4[binaryimage4==255])

    return(a,b,c,d,gm,area,gm1,gm2,gm3,gm4,area1,area2,area3,area4)