import numpy as np
from numpy.linalg import solve
import matplotlib.pyplot as plt
from sympy import symbols, solve, linsolve
np.set_printoptions(precision=4)
#print(np.pi * np.arange(8))
#输入五元核
A1=[830,1031,1232,1436,1640]
A0=[0,24,47,85,123]
G1=[130,145,160,180,200]
G0=[240,246,251,253,255]



a, b, c = symbols('a b c')
def func1(L):
    a, b, c = symbols('a b c')
    f1 = L[0]**2*a +L[0]*b + c 
    f2 =L[1]**2*a +L[1]*b + c-0.5
    f3 =L[2]**2*a +L[2]*b + c-1
    return(f1,f2,f3)

def func2(L):
    a, b, c = symbols('a b c')
    f1 = L[2]**2*a +L[2]*b + c-1
    f2 =L[3]**2*a +L[3]*b + c-0.5
    f3 =L[4]**2*a +L[4]*b + c
    return(f1,f2,f3)
    
# 输出系数a,b,c
'''A=G0
print(solve([func1(A)[0], func1(A)[1], func1(A)[2]]))
print(solve([func2(A)[0], func2(A)[1], func2(A)[2]]))'''

#画出函数
    #定义x、y散点坐标
'''x=[]
y=[]
y1=[]
for i in range (830,1640):
    x.append(i)
for j in range (len(x)):
    a1=0.00248756218905473*x[j]-2.06467661691542
    y.append(a1)
for j in range (len(x)):
    a2=-0.00245098039215686*x[j]+4.01960784313725
    y1.append(a2)
x=np.array(x)
y=np.array(y)
y1=np.array(y1)

plt.xlabel('x')
plt.ylabel('y')
plt.plot(x,y,'black',label='fx')
plt.plot(x,y1,'r',label='LR')
plt.title('exp')
plt.legend(loc=4) #指定legend的位置右下角
plt.show()'''

#参数记录
'''
A1={a: 0.0, b: 0.00248756218905473, c: -2.06467661691542}
{a: 0.0, b: -0.00245098039215686, c: 4.01960784313725}

A0={a: 1.92722787542399e-5, b: 0.0203707986432316, c: 0.0}
{a: 0.0, b: -0.0131578947368421, c: 1.61842105263158}


G1={a: 0.0, b: 0.0333333333333333, c: -4.33333333333333}
{a: 0.0, b: -0.0250000000000000, c: 5.00000000000000}

G0={a: 0.00151515151515152, b: -0.653030303030303, c: 69.4545454545455}
{a: 0.0, b: -0.250000000000000, c: 63.7500000000000}
'''
#A1
def A1 (x):
    f=0
    if x>=830 and x<=1232:
        f1=0.00248756218905473*x-2.06467661691542
        f=f1
    if x>1232 and x<=1640:
        f2=-0.00245098039215686*x+4.01960784313725
        f=f2
    return(f)
#A0
def A0 (x):
    f=0
    if x>=0 and x<=47:
        f1=0.0000192722787542399*x**2+0.0203707986432316*x+0
        f=f1
    if x>47 and x<=123:
        f2=0*x**2-0.0131578947368421*x+1.61842105263158
        f=f2
    return(f)

#G1
def G1 (x):
    f=0
    if x>=130 and x<=160:
        f1=0*x**2+0.0333333333333333*x-4.33333333333333
        f=f1
    if x>160 and x<=200:
        f2=0*x**2-0.0250000000000000*x+5.00000000000000
        f=f2
    return(f)

#G0
def G0 (x):
    f=0
    if x>=240 and x<=251:
        f1=0.00151515151515152*x**2-0.653030303030303*x+69.4545454545455
        f=f1
    if x>251 and x<=255:
        f2=0*x**2-0.250000000000000*x+63.7500000000000
        f=f2
    return(f)
print(G0(255))