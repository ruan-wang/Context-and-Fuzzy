import cv2
import imutils
import numpy as np
import pandas as pd

corpus = pd.read_csv('Label\\all_y_trues.csv',header=0, names=["y_trues"]) # 得到 DataFrame
corpus = np.array(corpus)  # 转换为 ndarray [[1], [2], [3]]
corpus = corpus.reshape(1, len(corpus)).tolist()  # 转换成 List [[1, 2, 3]]
corpus = corpus[0]  # 取第一个元素得到最终结果 [1, 2, 3]
all_y_trues = np.array(corpus)

G0=[]
G1=[]

for i in range(len(all_y_trues)):
    if all_y_trues[i]==0:
        image=cv2.imread("Training set\\{}.jpg".format(str(i+1)))
        grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
        gm=cv2.mean(grayimage)[0]
        G0.append(gm)
    if all_y_trues[i]==1:
        image=cv2.imread("Training set\\{}.jpg".format(str(i+1)))
        grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
        gm=cv2.mean(grayimage)[0]
        G1.append(gm)

#数值写入CSV文件
G0 = np.array(G0)
G1 = np.array(G1)
# 先转为DataFrame格式
name=["G0"]
df1 = pd.DataFrame(columns=name, data=G0)
df1.to_csv("membership function\\statistics results\\\\G0.csv")
name=["G1"]
df2 = pd.DataFrame(columns=name, data=G1)
df2.to_csv("membership function\\statistics results\\\\G1.csv")