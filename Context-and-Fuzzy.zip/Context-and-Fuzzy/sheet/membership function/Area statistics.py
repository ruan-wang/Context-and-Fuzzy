import cv2
import imutils
import numpy as np
import pandas as pd

corpus = pd.read_csv('Label\\all_y_trues.csv',header=0, names=["y_trues"]) # 得到 DataFrame
corpus = np.array(corpus)  # 转换为 ndarray [[1], [2], [3]]
corpus = corpus.reshape(1, len(corpus)).tolist()  # 转换成 List [[1, 2, 3]]
corpus = corpus[0]  # 取第一个元素得到最终结果 [1, 2, 3]
all_y_trues = np.array(corpus)

A0=[]
A1=[]

for i in range(len(all_y_trues)):
    if all_y_trues[i]==0:
        image=cv2.imread("Training set\\{}.jpg".format(str(i+1)))
        grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
        _O, binaryimage = cv2.threshold(grayimage, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        area=len(binaryimage[binaryimage==255])
        A0.append(area)
    if all_y_trues[i]==1:
        image=cv2.imread("Training set\\{}.jpg".format(str(i+1)))
        grayimage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#灰度
        _O, binaryimage = cv2.threshold(grayimage, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        area=len(binaryimage[binaryimage==255])
        A1.append(area)
    print(i+1)
print(A0)
print(A1)
#数值写入CSV文件
A0 = np.array(A0)
A1 = np.array(A1)
# 先转为DataFrame格式
name=["A0"]
df1 = pd.DataFrame(columns=name, data=A0)
df1.to_csv("membership function\\statistics results\\A0.csv")
name=["A1"]
df2 = pd.DataFrame(columns=name, data=A1)
df2.to_csv("membership function\\statistics results\\A1.csv")