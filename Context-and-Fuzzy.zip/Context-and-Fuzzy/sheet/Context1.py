import cv2 as cv
import numpy as np
from preprocessing import imgpre

#欧式比较
def Eucdis(gm,area,aaa,bbb):
    k=0
    d=100

    pdist1=((gm-aaa)**2)**0.5 
    pdist2=((area-bbb)**2)**0.5 
    d=(pdist1+pdist2)/2
    #精度控制
    d=int(d)
    d=((d-2)/561)*100
    if d<=5:
        k=1
    return k

def context(GM,AREA,GM1,AREA1):
    #####排序##########
    A=[GM1]#灰度越小越真
    A1=sorted(A)
    A2=[A.index(A1[0])]#升序排列的A的下标
    B=[AREA1]#面积越大越真。
    B1=sorted(B,reverse = True)
    B2=[B.index(B1[0])]#降序排列的B的下标
    aa=A[A2[0]]
    bb=B[B2[0]]
    #####排序##########    

####把上下文的类别传给当前目标###
    if B2[0]==0:
        Cate='A'
    if B2[0]==1:
        Cate='B'
    if B2[0]==2:
        Cate='C'
    if B2[0]==3:
        Cate='D'

    d=Eucdis(GM,AREA,aa,bb)
    return d,Cate




#上下文比较
def contextcmp(image,his,key):
    
#所有选项的特征
    #当前这道题
    gm1=imgpre(image)[6]
    gm2=imgpre(image)[7]
    gm3=imgpre(image)[8]
    gm4=imgpre(image)[9]
    area1=imgpre(image)[10]
    area2=imgpre(image)[11]
    area3=imgpre(image)[12]
    area4=imgpre(image)[13]
    #上一道题
    gm1p=imgpre(his)[6]
    gm2p=imgpre(his)[7]
    gm3p=imgpre(his)[8]
    gm4p=imgpre(his)[9]
    area1p=imgpre(his)[10]
    area2p=imgpre(his)[11]
    area3p=imgpre(his)[12]
    area4p=imgpre(his)[13]
     
    
    #上下文对比算法
    if key==1:

        k=context(gm1,area1,gm4p,area4p)[0]
        #categ=context(gm1,area1,gm4p,gm3p,gm2p,area4p,area3p,area2p)[1]
        categ='A'
        


    if key==2:

        k=context(gm2,area2,gm1,area1)[0]
        #categ=context(gm2,area2,gm1,gm4p,gm3p,area1,area4p,area3p)[1]
        categ='B'
    
    if key==3:

        k=context(gm3,area3,gm2,area2)[0]
        #categ=context(gm3,area3,gm2,gm1,gm4p,area2,area1,area4p)[1]
        categ='C'
        
    if key==4:

        k=context(gm4,area4,gm3,area3)[0]
        #categ=context(gm4,area4,gm3,gm2,gm1,area3,area2,area1)[1]
        categ='D'
 
    return k,categ













