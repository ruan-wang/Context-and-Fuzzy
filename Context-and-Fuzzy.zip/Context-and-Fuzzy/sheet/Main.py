# -*- coding: UTF-8 -*-
import sys
import io
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf8')
from multiprocessing import context
import os
from tkinter import image_names
from unicodedata import category
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import torch
from torch.autograd import Variable
from M_function import fix
import numpy as np
import cv2

import random
from random import sample
from M_function import A1,A0,M_degree
from preprocessing import imgpre
#from FNNwithCtex import Judge



from multiprocessing import context
import os
from tkinter import image_names
from unicodedata import category
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import torch
from torch.autograd import Variable
import numpy as np
import cv2
from Context1 import contextcmp
import random
from random import sample
from M_function import A1,A0,M_degree
from preprocessing import imgpre

#加载训练好的网络
#net = torch.load('network2\\net2.pth')
net = torch.load('network\\network H10\\net1.pth')

#网络输出
def OutPut(data):
    target = np.array(data)
    target = torch.from_numpy(target).float()

    target=(net(target))[0][0]
    return('%.20f' % target)


def Judge(img,imghis,J,dir):
    
    #读入图像和图像编号
    image=img
    his=imghis
    index=J

    #四个填涂选项隶属数据化
    A=M_degree(imgpre(image)[0])
    B=M_degree(imgpre(image)[1])
    C=M_degree(imgpre(image)[2])
    D=M_degree(imgpre(image)[3])
    #保存四个选项的隶属数据
    degreeA=[]
    degreeA.append(A)
    degreeB=[]
    degreeB.append(B)
    degreeC=[]
    degreeC.append(C)
    degreeD=[]
    degreeD.append(D)




    #预测结果(0~1之间)
    a=float(OutPut(degreeA))
    b=float(OutPut(degreeB))
    c=float(OutPut(degreeC))
    d=float(OutPut(degreeD))


    #10
    a=((a-0.03)/abs(0.030774057-0.667094231))*100
    b=((b-0.03)/abs(0.030774057-0.667094231))*100
    c=((c-0.03)/abs(0.030774057-0.667094231))*100
    d=((d-0.03)/abs(0.030774057-0.667094231))*100
    results=[]
    
    

    a=fix(a)
    b=fix(b)
    c=fix(c)
    d=fix(d)




#对每一个选项进行预测（不确定区间&上下文）

    #context为上下文算法，image为当前选项所在图片，imagehis为上一张图片，1、2、3、4为选项编号
    #不确定区间范围
    kkk=0    #k=0~4
    U=22+kkk
    H=30+kkk
    
    if a>=H:
        results.append('A')
    if a>=U and a<H:
        k=contextcmp(image,his,1)[0]
        category=contextcmp(image,his,1)[1]
        if k==1:
            results.append(category)


    if b>=H:
        results.append('B')
    if b>=U and b<H:
        k=contextcmp(image,his,2)[0]
        category=contextcmp(image,his,2)[1]
        if k==1:
            results.append(category)


    if c>=H:
        results.append('C')
    if c>=U and c<H:
        k=contextcmp(image,his,3)[0]
        category=contextcmp(image,his,3)[1]
        if k==1:
            results.append(category)


    if d>=H:
        results.append('D')
    if d>=U and d<H:
        k=contextcmp(image,his,4)[0]
        category=contextcmp(image,his,4)[1]
        if k==1:
            results.append(category)

    #缺陷补全
    if index==0 and len(results)==0:
        results.append('Q')
     

    if index!=0 and len(results)==0:
        results.append('Q')
       

  
    return(results)































##批量读入图像路径
Dir=[]
length=len(os.listdir("Testset"))

#读入图片
for i in range(length):
    Dir.append("Testset\\{}.jpg".format(str(i+1))) 


#输出每道题的结果
for j in range(length):
    if j==1000:
        break
    print("第",j+1,"张")
    image=cv2.imread(Dir[j])
    if j==0:
        imagehis=cv2.imread(Dir[j])
    if j>0:
        imagehis=cv2.imread(Dir[j-1])
    
    print(Judge(image,imagehis,j,Dir))

